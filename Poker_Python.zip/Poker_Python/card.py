# This is the card page which will draw the card and text and image stuff
import random
import pygame


## This class saves the rank and suit of a card
#
class Card:
    ## This constructor constructs the rank and suit of a card
    #
    def __init__(self):
        self._suit = ""
        self._rank = 0

    ## This method sets the rank of the card
    # @param rank the rank of a card
    #
    def setRank(self, rank):
        self._rank = rank

    ## This method sets the suit of the card
    # @param suit the suit of a card
    #
    def setSuit(self, suit):
        self._suit = suit

    ## This method returns the suit of this card
    # @return the suit of the card
    #
    def getSuit(self):
        return self._suit

    ## This method returns the rank of this card
    # @return the rank of the card
    #
    def getRank(self):
        return self._rank


## This class draws the text class
#
class Text:
    ## This is the contructor that constructs the text
    # @param x the x position
    # @param y the y position
    # @param text the text content
    # @param size the size of the text
    # @oaram color the color of the text
    #
    def __init__(self, x, y, text, size, color):
        pygame.font.init()
        self._font = pygame.font.Font('arial.ttf', size)
        self._text = self._font.render(text, True, color)
        self._text.get_rect()
        self._x = x
        self._y = y
        self._lowerX = 0
        self._lowerY = 0
        self._higherX = 0
        self._higherY = 0

    ## This method draws the text using display
    # @param display the display of the canvas
    #
    def drawText(self, display):
        display.blit(self._text, (self._x, self._y))

    ## This method draws the rectangle
    # @param x the x position
    # @param y the y position
    # @param display the display of the canvas
    #
    def drawRectangle(self, x, y, display):
        color = (0, 0, 0, 0)
        pygame.draw.rect(display, color, (self._x - 5, self._y,  x, y), 1)
        # pygame.draw.rect(display, color, (645, 530, 10, 10), 1)
        self._lowerX = self._x - 5
        self._lowerY = self._y
        self._higherX = self._lowerX + x
        self._higherY = self._lowerY + y

    ## This function returns the lower x
    # return lowerX
    #
    def getLowerX(self):
        return self._lowerX

    ## This function returns the lower y
    # return lowerY
    #
    def getLowerY(self):
        return self._lowerY

    ## This function returns the higher x
    # return higherX
    #
    def getHigherX(self):
        return self._higherX

    ## This function returns the higher y
    # return higherY
    #
    def getHigherY(self):
        return self._higherY


## This class draws the card
#
class CardImage:
    ## This constructor initialize the card
    # @param x the x position
    # @param y the y position
    # @param isBack whether the card is back
    #
    def __init__(self, x, y, isBack):
        self._x = x
        self._y = y
        self._cardBasic = Card()
        if isBack:
            self._cardName = self.randomPoker()
            self._filename = "DECK/b.gif"
        else:
            self._cardName = self.randomPoker()
            self._filename = self._cardName
        self._card = ImageSprite(self._x, self._y, self._filename)

    ## This method adds the path manually
    # @param suit the suit of the card
    # @param rank the rank of the card
    #
    def setPath(self, rank, suit):
        self._cardBasic.setRank(rank)
        self._cardBasic.setSuit(suit)
        st = "DECK/"
        st += rank
        st += suit
        st += ".gif"
        self._cardName = st

    ## This method randomlize a rank
    # @return the random rank
    #
    def randomRank(self):
        r = random.randint(1, 13)
        self._cardBasic.setRank(r)
        return str(r)

    ## This method randomlize a suit
    # @return the random suit
    #
    def randomSuit(self):
        suit = random.randint(1, 4)
        if suit == 1:
            self._cardBasic.setSuit("c")
        elif suit == 2:
            self._cardBasic.setSuit("s")
        elif suit == 3:
            self._cardBasic.setSuit("d")
        else:
            self._cardBasic.setSuit("h")
        return self._cardBasic.getSuit()

    ## This method randomlize a poker filename
    # @return the string of the filename
    #
    def randomPoker(self):
        st = "DECK/"
        st += self.randomRank()
        st += self.randomSuit()
        st += ".gif"
        return st

    ## This method draws the card to the x and y position
    #
    def drawCard(self, sprite):
        sprite.add(self._card)

    ## Sets the position of the card
    # @param x the x position
    # @param y the y position
    #
    def setPosition(self, x, y):
        self._x = x
        self._y = y

    ## Kills the object so that it won't appear on canvas
    #
    def kill(self):
        self._card.kill()

    ## Draw the card to the canvas
    #
    def showCard(self):
        self._card = ImageSprite(self._x, self._y, self._cardName)

    ## Gets the x and y position of the card
    # @return the x and y position
    def getPosition(self):
        return self._x, self._y

    ## Return the suit of the card
    # @return the suit
    def getSuit(self):
        return self._cardBasic.getSuit()

    ## Return the rank of the card
    # @return the rank
    def getRank(self):
        return self._cardBasic.getRank()

    ## Return the Card
    # @return the card
    def getCardBasic(self):
        return self._cardBasic


## This class loads image to the canvas
#
class ImageSprite(pygame.sprite.Sprite):
    ## This constructor constructs the image and initialize the x and y position
    # @param x the x position
    # @param y the y position
    # @param filename the filename of the image
    #
    def __init__(self, x, y, filename):
        super().__init__()
        self.loadImage(x, y, filename)

    ## This method loads the image to the canvas
    # @param x the x position
    # @param y the y position
    # @param filename the filename of the image
    #
    def loadImage(self, x, y, filename):
        img = pygame.image.load(filename).convert()
        MAGENTA = (255, 0, 255)
        img.set_colorkey(MAGENTA)
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y - self.rect.height

    ## This method moves the image by direction
    # @param dx the x position that is moving
    # @param dy the y position that is moving
    #
    def moveBy(self, dx, dy):
        self.rect.x += dx
        self.rect.y += dy
