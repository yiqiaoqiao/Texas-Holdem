# This is the deck class which will save all the card into a deck
# It also includes CheckHand which will check the hand of a deck of card

## This class saves a deck of card
#
class Deck:
    ## This constructor initialize the deck of cards
    #
    def __init__(self):
        self._deck = []

    ## This method adds a card to the deck
    # @param card the card that is adding
    #
    def addCard(self, card):
        self._deck.append(card)

    ## Draws the deck on the sprite
    # @param sprites the sprite of the canvas
    #
    def drawCard(self, sprites):
        for i in range(len(self._deck)):
            self._deck[i].drawCard(sprites)

    ## Clear the deck of card
    #
    def clear(self):
        for i in range(len(self._deck)):
            self._deck[i].kill()
        self._deck.clear()

    ## Return the card at i position
    # @param i the position in the list
    # @return the card
    #
    def getCard(self, i):
        return self._deck[i]

    ## Get the length of the deck
    # @return the length of the deck
    #
    def getLength(self):
        return len(self._deck)

    ## Return the deck
    # @return the deck
    #
    def getDeck(self):
        return self._deck


## This class check for the hand of a card
#
class CheckHand:
    ## This constructor construct a card deck
    #
    def __init__(self):
        self._card = []
        self._type = ""

    ## This method initialize the deck of the card
    # @param publicCard the public deck of the card
    # @param card the deck of a card
    #
    def initializeCard(self, publicCard, card):
        temp = []
        for i in range(len(publicCard)):
            temp.append(publicCard[i].getCardBasic())
        for i in range(len(card)):
            temp.append(card[i].getCardBasic())

        # Change Ace to 14 because Ace is the highest Card
        for i in range(len(temp)):
            if temp[i].getRank() == 1:
                temp[i].setRank(14)
        temp.sort(key=lambda x: x._rank)
        return temp

    ## Checks which type of hands the card is
    # @param publicCard the public deck of the card
    # @param card the deck of a card
    #
    def checkHand(self, publicCard, card):
        self._card = self.initializeCard(publicCard, card)
        if self.royalFlush():
            self._type = "royalFlush"
            return 10
        elif self.straightFlush():
            self._type = "straightFlush"
            return 9
        elif self.fourOfAKind():
            self._type = "fourOfAKind"
            return 8
        elif self.fullHouse():
            self._type = "fullHouse"
            return 7
        elif self.flush():
            self._type = "flush"
            return 6
        elif self.straight():
            self._type = "straight"
            return 5
        elif self.threeOfAKind():
            self._type = "threeOfAKind"
            return 4
        elif self.twoPairs():
            self._type = "twoPairs"
            return 3
        elif self.pair():
            self._type = "pair"
            return 2
        else:
            self._type = "highCard"
            return 1

    ## Checks if the array of card has same suit
    # @param a the starting of list
    # @param the end of the list
    # @return true if same suit
    #
    def sameSuit(self, a, b):
        suit = self._card[a].getSuit()
        for i in range(a+1, b):
            if self._card[i].getSuit() != suit:
                return False
        return True

    ## Checks if the array of card is a sequence
    # @param a the starting of list
    # @param the end of the list
    # @return true if is a sequence
    #
    def inSequence(self, a, b):
        c = b
        for i in range(a, b-1):
            if self._card[i + 1].getRank() == self._card[i].getRank():
                if c != 7:
                    c += 1
        for i in range(a, c-1):
            if self._card[i+1].getRank() - self._card[i].getRank() != 1:
                if self._card[i+1].getRank() != self._card[i].getRank():
                    return False
        return True

    ## Checks if the array of card has same value
    # @param a the starting of list
    # @param the end of the list
    # @return true if same value
    #
    def sameValue(self, a, b):
        value = self._card[a].getRank()
        for i in range(a+1, b):
            if self._card[i].getRank() != value:
                return False
        return True

    ## Checks if the array of card is royal flush
    # @return true if is royal flush
    #
    def royalFlush(self):
        a = 0
        b = 5
        while b <= 7:
            if self._card[a].getRank() == 10:
                if self.inSequence(a, b):
                    if self.sameSuit(a, b):
                        return True
            a += 1
            b += 1
        return False

    ## Checks if the array of card is straight flush
    # @return true if is straight flush
    #
    def straightFlush(self):
        a = 0
        b = 5
        while b <= 7:
            if self.inSequence(a, b):
                if self.sameSuit(a, b):
                    return True
            a += 1
            b += 1
        return False

    ## Checks if the array of card is four of a kind
    # @return true if is four of a kind
    #
    def fourOfAKind(self):
        a = 0
        b = 4
        while b <= 7:
            if self.sameValue(a, b):
                return True
            a += 1
            b += 1
        return False

    ## Checks if the array of card is full house
    # @return true if is full house
    #
    def fullHouse(self):
        a = 0
        b = 3
        threeKind = False
        while b <= 7:
            if self.sameValue(a, b):
                b -= 1
                threeKind = True
                break
            a += 1
            b += 1
        c = 0
        d = 2
        pair = False
        while d <= 7:
            if self.sameValue(c, d):
                if c < a or c > b:
                    if d < a or d > b:
                        pair = True
                        break
            c += 1
            d += 1
        if threeKind and pair:
            return True
        return False

    ## Checks if the array of card is flush
    # @return true if is flush
    #
    def flush(self):
        s = 0
        d = 0
        c = 0
        h = 0
        for i in range(len(self._card)):
            if self._card[i].getSuit() == "s":
                s += 1
            elif self._card[i].getSuit() == "d":
                d += 1
            elif self._card[i].getSuit() == "c":
                c += 1
            elif self._card[i].getSuit() == "h":
                h += 1
        if s >= 5 or d >= 5 or c >= 5 or h >= 5:
            return True
        return False

    ## Checks if the array of card is straight
    # @return true if is straight
    #
    def straight(self):
        a = 0
        b = 5
        while b <= 7:
            if self.inSequence(a, b):
                return True
            a += 1
            b += 1
        return False

    ## Checks if the array of card is three of a kind
    # @return true if is three of a kind
    #
    def threeOfAKind(self):
        a = 0
        b = 3
        while b <= 7:
            if self.sameValue(a, b):
                return True
            a += 1
            b += 1
        return False

    ## Checks if the array of card is two pairs
    # @return true if is two pairs
    #
    def twoPairs(self):
        a = 0
        b = 2
        firstPair = False
        while b <= 7:
            if self.sameValue(a, b):
                b -= 1
                firstPair = True
                break
            a += 1
            b += 1
        c = 0
        d = 2
        secondPair = False
        while d <= 7:
            if self.sameValue(c, d):
                if c != a and d-1 != b:
                    secondPair = True
                    break
            c += 1
            d += 1
        if firstPair and secondPair:
            return True
        return False

    ## Checks if the array of card is a pair
    # @return true if is three of a pair
    #
    def pair(self):
        a = 0
        b = 2
        while b <= 7:
            if self.sameValue(a, b):
                return True
            a += 1
            b += 1
        return False

    ## Finds the highest rank of the deck of card
    # @return the highest rank
    #
    def highCard(self):
        if self._card[6].getRank() == 14:
            return "Ace"
        elif self._card[6].getRank() == 13:
            return "King"
        elif self._card[6].getRank() == 12:
            return "Queen"
        elif self._card[6].getRank() == 11:
            return "Jack"
        return str(self._card[6].getRank())

    ## Return what type of hand it is
    # @return the type of hand
    #
    def getType(self):
        return self._type
