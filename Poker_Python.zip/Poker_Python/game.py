# This is the game page which initialize the canvas and all the displays. Then the game will
# check for user input and mouse click and update all the information
import pygame
from gameBase import GameBase


## This class draws the card and the game to the canvas
#
class Game:
    ## This constructor initialize the canvas
    #
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Poker Game")
        self._display = pygame.display.set_mode((800, 800))
        self._clock = pygame.time.Clock()
        self._framesPerSecond = 30
        self._sprites = pygame.sprite.LayeredUpdates()
        self._ticks = 0
        pygame.key.set_repeat(1, 120)
        self._gameBase = GameBase(100, 100)
        self._status = "NONE"
        self._isStart = False
        self._round = 0
        self._userText = ''
        self._isInBox = False

    ## This method update the canvas
    #
    def update(self):
        background = pygame.Surface(self._display.get_size())
        self._sprites.clear(self._display, background)
        self._sprites.update()

    ## This method draws the canvas
    #
    def draw(self):
        self._gameBase.drawAllCard(self._sprites)
        self._gameBase.drawAllText(self._display, self._userText)
        self._sprites.draw(self._display)

    ## This method adds the sprite to the total sprite
    # @param sprite the sprite that is added
    #
    def add(self, sprite):
        self._sprites.add(sprite)

    ## This method will close the canvas
    #
    def quit(self):
        pygame.quit()

    ## This method checks the status of the game
    #
    def checkStatue(self):
        if self._status == "START":
            if self._gameBase.userHasMoney() or self._gameBase.AIHasMoney():
                self._userText = ""
                self._isStart = True
                self._round = 0
                self._gameBase.start()
                self._gameBase.clear()
                self._gameBase.initialCard()
        elif self._status == "STAY":
            if self._isStart:
                self._gameBase.addCard()
                self._round += 1
        elif self._status == "FOLD":
            self._isStart = False
            self._gameBase.addAmount(False)
            self._gameBase.restart()
        elif self._status == "RAISE":
            if self._userText.isdigit():
                # print(int(self._userText))
                if self._gameBase.canRaise(int(self._userText)) and self._isStart:
                    self._gameBase.changeAmount(int(self._userText))
                    self._gameBase.addCard()
                    self._round += 1

        # Check for round
        if self._round == 2:
            self._isStart = False
            self._gameBase.checkHand()
            self._gameBase.restart()

    ## This method runs everything and display the canvas
    #
    def run(self):
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.quit()
                    quit()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    mpos = pygame.mouse.get_pos()
                    if self._gameBase.isInBox(mpos[0], mpos[1]):
                        self._isInBox = True
                    else:
                        self._isInBox = False
                    self._gameBase.setBox(self._isInBox)
                    self._status = self._gameBase.checkPos(mpos[0], mpos[1])
                    self.checkStatue()
                elif event.type == pygame.KEYUP:
                    if self._isInBox:
                        if event.key == pygame.K_BACKSPACE:
                            self._userText = self._userText[:-1]
                        else:
                            self._userText += event.unicode

            self.update()
            COLOR = (154, 205, 50)
            self._display.fill(COLOR)
            self.draw()
            pygame.display.update()
            self._clock.tick(self._framesPerSecond)
            self._ticks += 1
