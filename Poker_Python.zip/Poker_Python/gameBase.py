# This file is the game base of the game, which includes drawing the canvas and save the money
# the player and the AI has
import pygame
from deck import Deck
from person import Person
from card import CardImage, Text

## This class is the base of the game which connects person, gui and deck together
#
class GameBase:
    ## This constructor constructs the everything including gui and ai and user
    # @param userWage the wage that the user has
    # @param AIWage the wage that AI has
    #
    def __init__(self, userWage, AIWage):
        # Set public Card
        self._publicDeck = Deck()

        # Set AI and User
        self._AI = Person(AIWage)
        self._user = Person(userWage)

        # Set all the text
        self._pot = Text(600, 30, "POT: ", 30, "Black")
        self._start = Text(620, 100, "start", 25, "Black")
        self._stay = Text(100, 500, "stay", 25, "Black")
        self._raise = Text(450, 500, "raise", 25, "Black")
        self._fold = Text(600, 500, "fold", 25, "Black")
        self._AIWageText = Text(30, 70, "AI wage: $" + str(AIWage), 20, "Black")
        self._userWageText = Text(30, 600, "user wage: $" + str(userWage), 20, "Black")

        # Set others
        self._inBox = False
        self._isStart = False
        self._potAmount = 0

    ## This method initialize the gui cards of public card, AI card and user card
    #
    def initialCard(self):
        card = CardImage(50, 450, False)
        card2 = CardImage(200, 450, False)
        card3 = CardImage(350, 450, False)
        self._publicDeck.addCard(card)
        self._publicDeck.addCard(card2)
        self._publicDeck.addCard(card3)

        card4 = CardImage(200, 250, True)
        card5 = CardImage(400, 250, True)
        self._AI.addCard(card4)
        self._AI.addCard(card5)

        card6 = CardImage(200, 750, False)
        card7 = CardImage(400, 750, False)
        self._user.addCard(card6)
        self._user.addCard(card7)

    ## This method draws all card on the canvas
    # @param sprites the sprites of the canvas
    #
    def drawAllCard(self, sprites):
        self._publicDeck.drawCard(sprites)
        self._AI.drawCard(sprites)
        self._user.drawCard(sprites)

    ## This method draws all the text message on the canvas
    # @param display the display of the canvas
    # @param userText the text that the user input
    #
    def drawAllText(self, display, userText):
        self.drawBox(display)
        self.drawButton(display, userText)
        if not self._isStart and self._AI.getWage() < 20:
            text = Text(30, 20, "AI does not have enough money", 20, "Black")
            text.drawText(display)
        if not self._isStart and self._user.getWage() < 20:
            text = Text(30, 40, "User does not have enough money", 20, "Black")
            text.drawText(display)
        if not self._isStart:
            self._start.drawText(display)
            self._start.drawRectangle(60, 30, display)
            if self._AI.getWage() > 20 and self._user.getWage() > 20:
                text = Text(30, 20, "Click start to continue", 20, "Black")
                text.drawText(display)

    ## This method draw the user input box
    # @param display the display of the canvas
    #
    def drawBox(self, display):
        color = (34, 139, 34)
        white = (255, 255, 255)
        if self._inBox:
            pygame.draw.rect(display, white, pygame.Rect(300, 500, 140, 30))
        else:
            pygame.draw.rect(display, color, pygame.Rect(300, 500, 140, 30))

    ## This method draw the button of each text
    # @param display the display of the canvas
    # @param userText the text that the user input
    #
    def drawButton(self, display, userText):
        self._pot.drawText(display)
        self._stay.drawText(display)
        self._stay.drawRectangle(60, 30, display)
        self._raise.drawText(display)
        self._raise.drawRectangle(65, 30, display)
        self._fold.drawText(display)
        self._fold.drawRectangle(50, 30, display)
        self._AIWageText.drawText(display)
        self._userWageText.drawText(display)
        self.drawUserText(userText, display)

    ## This method checks if the position is within any of the button
    # @param x the x position
    # @param y the y position
    # @return which text the user click
    #
    def checkPos(self, x, y):
        if self._start.getLowerX() < x < self._start.getHigherX():
            if self._start.getLowerY() < y < self._start.getHigherY():
                return "START"
        if self._stay.getLowerX() < x < self._stay.getHigherX():
            if self._stay.getLowerY() < y < self._stay.getHigherY():
                return "STAY"
        if self._fold.getLowerX() < x < self._fold.getHigherX():
            if self._fold.getLowerY() < y < self._fold.getHigherY():
                return "FOLD"
        if self._raise.getLowerX() < x < self._raise.getHigherX():
            if self._raise.getLowerY() < y < self._raise.getHigherY():
                return "RAISE"
        return "NONE"

    ## This method sets the start canvas of the game
    #
    def start(self):
        self._isStart = True
        self._AI.putWage(20)
        self._user.putWage(20)
        self._potAmount += 40
        self._AIWageText = Text(30, 70, "AI wage: $" + str(self._AI.getWage()), 20, "Black")
        self._userWageText = Text(30, 600, "user wage: $" + str(self._user.getWage()), 20, "Black")
        self._pot = Text(600, 30, "POT: $" + str(self._potAmount), 30, "Black")

    ## This method adds the card to the public deck
    #
    def addCard(self):
        x, y = self._publicDeck.getCard(self._publicDeck.getLength() - 1).getPosition()
        card = CardImage(x + 150, y, False)
        self._publicDeck.addCard(card)

    ## This method restarts the canvas of the game
    #
    def restart(self):
        self._isStart = False
        self._potAmount = 0
        for i in range(self._AI.getDeck().getLength()):
            self._AI.getDeck().getCard(i).showCard()
        self._pot = Text(600, 30, "POT: ", 30, "Black")
        self._AIWageText = Text(30, 70, "AI wage: $" + str(self._AI.getWage()), 20, "Black")
        self._userWageText = Text(30, 600, "user wage: $" + str(self._user.getWage()), 20, "Black")

    ## This method clears every deck of card
    #
    def clear(self):
        self._publicDeck.clear()
        self._AI.clearDeck()
        self._user.clearDeck()

    ## This method sets of the user click the box
    # @param box true or false
    #
    def setBox(self, box):
        self._inBox = box

    ## This method checks if the position is in the box area
    # @param x the x position
    # @param y the y position
    # @return true if the position is within the user input box area
    #
    def isInBox(self, x, y):
        if 300 < x < 440 and 500 < y < 530:
            return True
        return False

    ## This method draws the user input to the canvas
    # @param userText the text that the user input
    # @param display the display of the canvas
    #
    def drawUserText(self, userText, display):
        text = Text(310, 502, userText, 20, "Black")
        text.drawText(display)

    ## This method change the amount of the wage
    # @param raiseAmount the amount that the user decides to raise
    #
    def changeAmount(self, raiseAmount):
        if self._AI.aboveWageAmount(raiseAmount) and self._user.aboveWageAmount(raiseAmount):
            self._AI.putWage(raiseAmount)
            self._user.putWage(raiseAmount)
            self._potAmount += raiseAmount * 2
            self._AIWageText = Text(30, 70, "AI wage: $" + str(self._AI.getWage()), 20, "Black")
            self._userWageText = Text(30, 600, "user wage: $" + str(self._user.getWage()), 20, "Black")
            self._pot = Text(600, 30, "POT: $" + str(self._potAmount), 30, "Black")

    ## This method checks which type of hands is AI and User have
    #
    def checkHand(self):
        AIHand = self._AI.checkHand(self._publicDeck.getDeck())
        userHand = self._user.checkHand(self._publicDeck.getDeck())
        # print("AI:", self._AI.getHandType())
        # print("User:", self._user.getHandType())
        if AIHand > userHand:
            self._AI.addWage(self._potAmount)
        elif userHand > AIHand:
            self._user.addWage(self._potAmount)
        else:
            self._AI.addWage(int(self._potAmount / 2))
            self._user.addWage(int(self._potAmount / 2))

    ## This method checks if user can raise this amount
    # @param raiseAmount the amount that the user decides to raise
    # @return AI and user true/false
    #
    def canRaise(self, raiseAmount):
        return self._AI.aboveWageAmount(raiseAmount) and self._user.aboveWageAmount(raiseAmount)

    ## This method adds the pot amount to the person's wage
    # @param isUser true if it is user, else it is AI
    #
    def addAmount(self, isUser):
        if isUser:
            self._user.addWage(self._potAmount)
        else:
            self._AI.addWage(self._potAmount)

    ## This method get the user input status
    # @return the inbox true/false
    #
    def getUserInputStatus(self):
        return self._inBox

    ## This method returns the wage amount that AI and user have
    # @return the AI wage and user wage
    #
    def getAmount(self):
        return self._AI.getWage(), self._user.getWage()

    ## This method checks if AI have enough money to start new round or not
    # @return true if AI has money above 20
    #
    def AIHasMoney(self):
        if self._AI.getWage() >= 20:
            return True
        return False

    ## This method checks if user have enough money to start new round or not
    # @return true if user has money above 20
    #
    def userHasMoney(self):
        if self._user.getWage() >= 20:
            return True
        return False
