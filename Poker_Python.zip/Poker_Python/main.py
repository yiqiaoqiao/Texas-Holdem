# This is the main page of the game which can start the game
from game import Game

game = Game()
game.run()
