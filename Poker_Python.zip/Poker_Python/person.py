# This is the person class which will save all the person's information including the deck of
# card and checking hand and the wage each person has
from deck import Deck, CheckHand


## This class saves each person's wage, deck of card, and which hand it is
#
class Person:
    ## This constructor construcs person's wage, deck of card, and the hand type
    # @param wage the starting wage this person has
    #
    def __init__(self, wage):
        self._wage = wage
        self._deck = Deck()
        self._hand = CheckHand()

    ## This method adds the card to the deck
    # @param card the card that is added to the deck
    #
    def addCard(self, card):
        self._deck.addCard(card)

    ## This method draws all the card to the canvas
    # @param sprites the sprites on the canvas
    #
    def drawCard(self, sprites):
        self._deck.drawCard(sprites)

    ## This method returns the wage of the person
    # @return the wage this person has
    #
    def getWage(self):
        return self._wage

    ## This method retuns the deck of the person
    # @return the deck this person has
    #
    def getDeck(self):
        return self._deck

    ## This method checks if the amount can be deduct from user
    # @param amount the amount that is deducting
    # @return true if the amount can be deducted
    #
    def aboveWageAmount(self, amount):
        if self._wage >= amount:
            return True
        return False

    ## This method deducts the amount from the wage
    # @param amount the amount that is deducting
    #
    def putWage(self, amount):
        if self.aboveWageAmount(amount):
            self._wage -= amount

    ## This method adds the amount to the current wage
    # @param amount the amount that is deducting
    #
    def addWage(self, amount):
        self._wage += amount

    ## This method clears the deck from canvas
    #
    def clearDeck(self):
        self._deck.clear()

    ## This method checks which type of hand the person has
    #
    def checkHand(self, publicDeck):
        return self._hand.checkHand(publicDeck, self.getDeck().getDeck())

    ## Return what type of hand the person has
    # @return the type of hand
    #
    def getHandType(self):
        return self._hand.getType()
